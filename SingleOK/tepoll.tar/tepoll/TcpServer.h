/*************************************************************************
 ************************************************************************/
#ifndef TCP_SERVER_H
#define TCP_SERVER_H

#include "command_define.h"
#include <set>
#include <list>
#include <sys/select.h>
#include <pthread.h>

typedef struct{
    char mac[13];
    char filename[128];
}FILENAMEMAC, *PFILENAMEMAC;

/*typedef struct{
    int sock;
    FILE *fp;
}DEV;
*/
class TcpServer
{
public:
    TcpServer();
    virtual ~TcpServer();
    bool Initialize(unsigned int nPort, unsigned long recvFunc);
    bool SendData(const unsigned char * szBuf, size_t nLen, int socket);
    bool UnInitialize();

private:
    static void * AcceptThread(void * pParam);
    static void * OperatorThread(void * pParam);
    static void * ManageThread(void * pParam);
    static PFILENAMEMAC CheckMacDirPath(char* pfilename);
private:
    int m_server_socket;
    fd_set m_fdReads;
    pthread_mutex_t m_mutex;
    pCallBack m_operaFunc;


    //int m_client_socket[MAX_LISTEN];
    std::set<int> m_client_socket;
   // std::set<DEV>m_client_dev;
    std::list<ServerData> m_data;
    pthread_t m_pidAccept;
    pthread_t m_pidManage;
};

#endif
